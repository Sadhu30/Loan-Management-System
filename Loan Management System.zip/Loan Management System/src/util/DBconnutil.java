package util;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class DBconnutil {
	private static Connection connection;

	   public DBconnutil() {
	   }

	   public static Connection getConnection() {
	      if (connection == null) {
	         try {
	            Class.forName("com.mysql.cj.jdbc.Driver");
	            String url = "jdbc:mysql://localhost:3306/loanmanagementsystem";
	            String username = "root";
	            String password = "Sadhana";
	            connection = DriverManager.getConnection(url, username, password);
	            System.out.println("Connection established: " + String.valueOf(connection));
	         } catch (SQLException | ClassNotFoundException var3) {
	            var3.printStackTrace();
	         }
	      }

	      return connection;
	   }
}
