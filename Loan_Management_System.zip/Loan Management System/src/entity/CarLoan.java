package entity;

public class CarLoan extends loan {
		   private String carModel;
		   private int carValue;

		   public String getCarModel() {
		      return this.carModel;
		   }

		   public void setCarModel(String carModel) {
		      this.carModel = carModel;
		   }

		   public int getCarValue() {
		      return this.carValue;
		   }

		   public void setCarValue(int carValue) {
		      this.carValue = carValue;
		   }

		   public CarLoan() {
		   }

		   public CarLoan(String carModel, int carValue) {
		      this.carModel = carModel;
		      this.carValue = carValue;
		   }
		}


