package entity;

public class loan {
	private int loanId;
	   private customer customer;
	   private double principalAmount;
	   private double interestRate;
	   private int loanTerm;
	   private String loanType;
	   private String loanStatus;

	   public loan() {
	   }

	   public int getLoanId() {
	      return this.loanId;
	   }

	   public void setLoanId(int loanId) {
	      this.loanId = loanId;
	   }

	   public customer getCustomer() {
	      return this.customer;
	   }

	   public void setCustomer(customer customer) {
	      this.customer = customer;
	   }

	   public double getPrincipalAmount() {
	      return this.principalAmount;
	   }

	   public double getInterestRate() {
	      return this.interestRate;
	   }

	   public void setInterestRate(double interestRate) {
	      this.interestRate = interestRate;
	   }

	   public int getLoanTerm() {
	      return this.loanTerm;
	   }

	   public void setLoanTerm(int loanTerm) {
	      this.loanTerm = loanTerm;
	   }

	   public String getLoanType() {
	      return this.loanType;
	   }

	   public void setLoanType(String loanType) {
	      this.loanType = loanType;
	   }

	   public String getLoanStatus() {
	      return this.loanStatus;
	   }

	   public void setLoanStatus(String loanStatus) {
	      this.loanStatus = loanStatus;
	   }

	   public void setprincipalAmount(double principalAmount) {
	      this.principalAmount = principalAmount;
	   }

	   public void setCustomerId(int customerId) {
	      this.customer = this.customer;
	   }
	}

