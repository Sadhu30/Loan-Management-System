package entity;

class HomeLoan extends loan {
	   private String propertyAddress;
	   private int propertyValue;

	   public String getPropertyAddress() {
	      return this.propertyAddress;
	   }

	   public void setPropertyAddress(String propertyAddress) {
	      this.propertyAddress = propertyAddress;
	   }

	   public int getPropertyValue() {
	      return this.propertyValue;
	   }

	   public void setPropertyValue(int propertyValue) {
	      this.propertyValue = propertyValue;
	   }

	   public HomeLoan()
	   {}
}
