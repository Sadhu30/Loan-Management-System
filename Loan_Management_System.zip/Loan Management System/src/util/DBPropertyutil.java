package util;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
public class DBPropertyutil {
	public DBPropertyutil() {
	   }

	   public static String getConnectionString(String propertyFileName) {
	      Properties properties = new Properties();

	      try {
	         Throwable var2 = null;
	         Object var3 = null;

	         try {
	            InputStream input = DBPropertyutil.class.getClassLoader().getResourceAsStream(propertyFileName);

	            InputStream var10000;
	            try {
	               if (input == null) {
	                  System.out.println("Sorry, unable to find " + propertyFileName);
	                  return null;
	               }

	               properties.load(input);
	               String url = properties.getProperty("url");
	               String user = properties.getProperty("user");
	               String password = properties.getProperty("password");
	               url.makeConcatWithConstants<invokedynamic>(url, user, password);
	            } finally {
	               var10000 = input;
	               if (input != null) {
	                  var10000 = input;
	                  input.close();
	               }

	            }

	            return var10000;
	         } catch (Throwable var15) {
	            if (var2 == null) {
	               var2 = var15;
	            } else if (var2 != var15) {
	               var2.addSuppressed(var15);
	            }

	            throw var2;
	         }
	      } catch (IOException var16) {
	         var16.printStackTrace();
	         return null;
	      }
	   }
}
